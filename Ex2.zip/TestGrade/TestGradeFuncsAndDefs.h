//#pragma once
//
//// Includes --------------------------------------------------------------------
//
//#include <windows.h>
//#include <stdio.h>
//#include <stdlib.h>
//
//
//// Constants -------------------------------------------------------------------
//
//#define MAX_FILE_NAME_SIZE 12
//#define NUM_OF_FILES 13
//#define LINE_IN_FILE_LENGTH 10
//#define NUM_OF_EXERCISES 10
//
//#define ERROR_CODE ((int)(-1))
//#define SUCCESS_CODE ((int)(0))
//
//#define ID_LENGTH 10
//#define PATH_TO_THREAD 36 //FIX//
//
//#define AVERAGE_SIZE 4
//#define FINAL_FILE_SIZE 80///
//
//#define ERROR_MESSAGE_SIZE 47
//#define PATH_FROM_CL  24
//
//// Structs ---------------------------------------------------------------------
//
//// Function Declarations -------------------------------------------------------
//
//
//
//
//
//
//
